extern void fs_output(void);
extern int fs_init(void);
extern void fs_close(void);
extern int fs_ok(void);  
extern void fs_add(void);








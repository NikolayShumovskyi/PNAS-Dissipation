extern int mutate_init(char * mut_name);
extern int mutate(void);

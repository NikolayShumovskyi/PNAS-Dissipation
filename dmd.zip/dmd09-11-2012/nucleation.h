extern int open_nucleation(char * fname);
extern void compute_nucleation(void);
extern int get_nucleus(void);

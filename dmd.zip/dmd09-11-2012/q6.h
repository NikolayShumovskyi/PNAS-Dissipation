extern int open_q6(char * fname);
extern void compute_q6(void);


void rng_init(unsigned int value);
unsigned int rng_get_seed(void);
unsigned int rng_int(void);
double rng(void);
double rng_gauss(double d);

extern int schedule_ok(void);
extern int schedule_init(void);
extern int read_schedule(void);

